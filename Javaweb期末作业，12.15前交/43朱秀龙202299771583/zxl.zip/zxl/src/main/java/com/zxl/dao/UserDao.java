package com.zxl.dao;


import com.zxl.domain.User;

public interface UserDao {
    int addUser(User user);
    User getUser(User user);
}
