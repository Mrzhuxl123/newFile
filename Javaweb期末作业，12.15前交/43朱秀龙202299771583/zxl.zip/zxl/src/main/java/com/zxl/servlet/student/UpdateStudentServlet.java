package com.zxl.servlet.student;


import com.zxl.dao.StudentDao;
import com.zxl.dao.daoImp.StudentImp;
import com.zxl.domain.Student;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;


@WebServlet("/UpdateStudentServlet")
public class UpdateStudentServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        Student student = new Student();
        student.setSex(req.getParameter("sex"));
        student.setSID(req.getParameter("SID"));
        student.setsName(req.getParameter("sName"));
        student.setSpecialty(req.getParameter("specialty"));
        System.out.println(student.getSex()+":"+student.getSID()+":"+student.getsName()+":"+student.getSpecialty());
        StudentDao studentDao = new StudentImp();
        int i = studentDao.updateStudent(student);
        if (i>0){
            System.out.println("更新成功");
            //重定向到查询页面
            resp.sendRedirect("GetAllServlet");
        }else {
            System.out.println("更新失败");
            //转发到失败页面
            //转发到失败页面
            req.getRequestDispatcher("error.html");
        }
    }
}
