package com.zxl.servlet.student;


import com.zxl.dao.StudentDao;
import com.zxl.dao.daoImp.StudentImp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns = "/DeleteStudentServlet")
public class DeleteStudentServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        StudentDao studentDao = new StudentImp();
        String sid = req.getParameter("SID");
        System.out.println("获取到删除的学生的学号："+sid);
        int deleteResult = studentDao.deleteStudent(sid);
        if (deleteResult>0){
            System.out.println("删除成功");
            //重定向到查询页面
            resp.sendRedirect("GetAllServlet");
        }else {
            System.out.println("删除失败");
            //转发到失败页面
            req.getRequestDispatcher("error.html");
        }
    }
}
