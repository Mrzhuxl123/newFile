package com.zxl.db;

import java.sql.*;

public class DBHelper {
    private final  static  String DRIVER = "com.mysql.jdbc.Driver";
    private final  static  String URL = "jdbc:mysql://localhost:3306/educ";
    private final  static  String USER = "root";
    private final  static  String PWD = "123";

    static {//静态代码块，类加载的时候会执行。
        try {
            Class.forName(DRIVER);
        }catch (Exception exception){
            exception.printStackTrace();
        }
    }

    public static Connection getConn() throws SQLException {
            return DriverManager.getConnection(URL,USER,PWD);
    }

    public static void closeAll(Connection connection, Statement statement, ResultSet resultSet){
        try {
            if (resultSet!=null){
                resultSet.close();
            }
            if (statement!=null){
                statement.close();
            }
            if (connection!=null){
                connection.close();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
