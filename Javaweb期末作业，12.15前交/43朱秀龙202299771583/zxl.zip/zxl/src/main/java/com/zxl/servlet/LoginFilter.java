package com.zxl.servlet;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebFilter(urlPatterns = {"/DeleteStudentServlet","/GetAllServlet","/GetStudentServlet","/GetStudentsServlet","/UpdateStudentServlet","/LoginOutServlet"})
public class LoginFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        Login login = new Login();
        boolean user = login.getUser((HttpServletRequest) request, (HttpServletResponse) response);
        if(user){
            System.out.println("用户已经登录" + "");
            chain.doFilter(request,response);
        }else {
            ((HttpServletResponse) response).sendRedirect("login.html");
        }
    }

    @Override
    public void destroy() {

    }
}
