package com.zxl.dao.daoImp;


import com.zxl.dao.UserDao;
import com.zxl.db.DBHelper;
import com.zxl.domain.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserImp implements UserDao {
    @Override
    public int addUser(User user) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int result = 0;
        try {
            connection = DBHelper.getConn();
            preparedStatement = connection.prepareStatement("insert into user(name,pwd) values(?,?)");
            preparedStatement.setString(1,user.getName());
            preparedStatement.setString(2,user.getPwd());
            result = preparedStatement.executeUpdate();
        }catch (Exception e){
            System.out.println("添加用户失败");
            e.printStackTrace();
        }finally {
            DBHelper.closeAll(connection,preparedStatement,null);
        }
        return result;
    }

    @Override
    public User getUser(User user) {
        Connection connection = null;
        PreparedStatement preparedStatement =null;
        ResultSet resultSet = null;
        User user1 = null;
        try {
            connection = DBHelper.getConn();
            preparedStatement = connection.prepareStatement("select * from user where name = ? and pwd = ?");
            preparedStatement.setString(1,user.getName());
            preparedStatement.setString(2,user.getPwd());
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                user1 = new User();
                user1.setName(resultSet.getString("name"));
                user1.setPwd(resultSet.getString("pwd"));
            }
        }catch (Exception e){
            System.out.println("获取用户失败");
            e.printStackTrace();
        }finally {
            DBHelper.closeAll(connection,preparedStatement,resultSet);
        }
        return user1;
    }
}
