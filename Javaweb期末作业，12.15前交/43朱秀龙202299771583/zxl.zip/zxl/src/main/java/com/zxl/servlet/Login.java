package com.zxl.servlet;

import com.zxl.domain.User;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class Login {
    //把用户保存到session中
    public void saveUser(HttpServletRequest request, HttpServletResponse response, User user){
        HttpSession session = request.getSession();
        session.setAttribute("userInfo",user);
    }
    //验证用户是否登录
    public boolean getUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
       if (session.getAttribute("userInfo")!=null){
           return true;
       }else {
           return false;
       }
    }
}
