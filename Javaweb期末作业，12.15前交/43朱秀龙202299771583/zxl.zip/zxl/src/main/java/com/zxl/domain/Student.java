package com.zxl.domain;

import java.sql.Timestamp;

public class Student {
    private String SID;
    private String sName;
    private String sex;
    private Timestamp birthday;
    private String specialty;

    public String getSID() {
        return SID;
    }

    public void setSID(String SID) {
        this.SID = SID;
    }

    public String getsName() {
        return sName;
    }

    public void setsName(String sName) {
        this.sName = sName;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Timestamp getBirthday() {
        return birthday;
    }

    public void setBirthday(Timestamp birthday) {
        this.birthday = birthday;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    @Override
    public String toString() {
        return "Student{" +
                "SID='" + SID + '\'' +
                ", sName='" + sName + '\'' +
                ", sex='" + sex + '\'' +
                ", birthday=" + birthday +
                ", specialty='" + specialty + '\'' +
                '}';
    }
}
