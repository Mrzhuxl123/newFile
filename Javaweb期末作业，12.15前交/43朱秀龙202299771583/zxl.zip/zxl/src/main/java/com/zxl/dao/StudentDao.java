package com.zxl.dao;


import com.zxl.domain.Student;

import java.util.List;

public interface StudentDao {
    List<Student> getStudents(String s);
    Student getStudent(String SID);
    int deleteStudent(String SID);
    int updateStudent(Student student);
    List<Student> getAll();
}
