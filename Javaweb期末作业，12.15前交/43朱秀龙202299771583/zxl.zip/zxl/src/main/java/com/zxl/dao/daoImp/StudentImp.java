package com.zxl.dao.daoImp;


import com.zxl.*;
import com.zxl.dao.StudentDao;
import com.zxl.db.DBHelper;
import com.zxl.domain.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentImp implements StudentDao {
    @Override
    //模糊查询
    public List<Student> getStudents(String s) {
        Connection connection = null;
        ResultSet resultSet = null;
        PreparedStatement preparedStatement = null;
        List<Student> students = new ArrayList<>();
        try{
            connection = DBHelper.getConn();
            preparedStatement = connection.prepareStatement("select * from student where Sname like ?");
            preparedStatement.setString(1,"%"+s+"%");
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                Student student = new Student();
                student.setBirthday(resultSet.getTimestamp("Birthday"));
                student.setSex(resultSet.getString("Sex"));
                student.setSID(resultSet.getString("SID"));
                student.setsName(resultSet.getString("Sname"));
                student.setSpecialty(resultSet.getString("Specialty"));
                students.add(student);
            }
        }catch (Exception e){
            System.out.println("模糊查询学生出错");
            e.printStackTrace();
        }finally {
            DBHelper.closeAll(connection,preparedStatement,resultSet);
        }
        return students;
    }

    @Override
    public Student getStudent(String SID) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        Student student = null;
        try{
            connection = DBHelper.getConn();
            preparedStatement = connection.prepareStatement("select * from student where SID = ?");
            preparedStatement.setString(1,SID);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                student = new Student();
                student.setSpecialty(resultSet.getString("Specialty"));
                student.setsName(resultSet.getString("Sname"));
                student.setSID(resultSet.getString("SID"));
                student.setSex(resultSet.getString("Sex"));
                student.setBirthday(resultSet.getTimestamp("Birthday"));
            }
        }catch (Exception e){
            System.out.println("查询指定学生错误");
            e.printStackTrace();
        }finally {
            DBHelper.closeAll(connection,preparedStatement,resultSet);
        }
        return student;
    }

    @Override
    public int deleteStudent(String SID) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int result = 0;
        try{
            connection = DBHelper.getConn();
            preparedStatement = connection.prepareStatement("delete from student where SID = ?");
            preparedStatement.setString(1,SID);
            result = preparedStatement.executeUpdate();
        }catch (Exception e){
            System.out.println("删除学生错误");
            e.printStackTrace();
        }finally {
            DBHelper.closeAll(connection,preparedStatement,null);
        }
        return result;
    }

    @Override
    public int updateStudent(Student student) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int result = 0;
        try{
            connection = DBHelper.getConn();
            preparedStatement = connection.prepareStatement("update student set Sname = ?,Sex = ?,Specialty = ? where SID = ?");
            preparedStatement.setString(1,student.getsName());
            preparedStatement.setString(2,student.getSex());
            preparedStatement.setString(3,student.getSpecialty());
            preparedStatement.setString(4,student.getSID());
            result = preparedStatement.executeUpdate();
            System.out.println("更新结果为"+result);
        }catch (Exception e){
            System.out.println("更新学生出错");
            e.printStackTrace();
        }finally {
            DBHelper.closeAll(connection,preparedStatement,null);
        }
        return result;
    }

    @Override
    public List<Student> getAll() {
        Connection connection = null;
        ResultSet resultSet = null;
        PreparedStatement preparedStatement = null;
        List<Student> students = new ArrayList<>();
        try{
            connection = DBHelper.getConn();
            preparedStatement = connection.prepareStatement("select * from student");
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                Student student = new Student();
                student.setBirthday(resultSet.getTimestamp("Birthday"));
                student.setSex(resultSet.getString("Sex"));
                student.setSID(resultSet.getString("SID"));
                student.setsName(resultSet.getString("Sname"));
                student.setSpecialty(resultSet.getString("Specialty"));
                students.add(student);
            }
        }catch (Exception e){
            System.out.println("查询所有学生出错");
            e.printStackTrace();
        }finally {
            DBHelper.closeAll(connection,preparedStatement,resultSet);
        }
        return students;
    }
}
