package com.zxl.servlet.student;
import com.zxl.dao.StudentDao;
import com.zxl.dao.daoImp.StudentImp;
import com.zxl.domain.Student;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


@WebServlet("/GetStudentServlet")
public class GetStudentServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        String sid = req.getParameter("SID");
        System.out.println("获取的学生ID为"+sid);
        StudentDao studentDao = new StudentImp();
        Student student = studentDao.getStudent(sid);
        System.out.println(student.toString());
        req.setAttribute("student", student);
        req.getRequestDispatcher("studentInfo.jsp").forward(req,resp);
    }
}
