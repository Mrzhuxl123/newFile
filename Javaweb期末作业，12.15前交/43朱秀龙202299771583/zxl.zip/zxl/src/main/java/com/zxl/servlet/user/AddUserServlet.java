package com.zxl.servlet.user;

import com.zxl.dao.daoImp.UserImp;
import com.zxl.domain.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/AddUserServlet")
public class AddUserServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        String name = req.getParameter("name");
        String pwd = req.getParameter("pwd");
        User user = new User();
        user.setName(name);
        user.setPwd(pwd);
        System.out.println("前端获取到用户:"+user.toString());
        UserImp userImp = new UserImp();
        int i = userImp.addUser(user);
        if (i>0){
            System.out.println("注册成功");
            resp.sendRedirect("loginSuccess.html");
        }else{
            resp.sendRedirect("registerFail.html");
        }
    }
}
