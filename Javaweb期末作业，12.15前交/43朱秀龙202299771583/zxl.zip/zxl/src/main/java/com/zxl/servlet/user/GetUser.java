package com.zxl.servlet.user;

import com.zxl.dao.daoImp.UserImp;
import com.zxl.domain.User;
import com.zxl.servlet.Login;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/GetUser")
public class GetUser extends HttpServlet {
    @Override
    //用户验证登录
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        String name = req.getParameter("name");
        String pwd = req.getParameter("pwd");
        User user = new User();
        user.setPwd(pwd);
        user.setName(name);
        System.out.println("前端传来用户"+user.toString());
        UserImp userImp = new UserImp();
        User user1 = userImp.getUser(user);
        if (user1!=null){
            System.out.println("登录成功");
            Login login = new Login();
            login.saveUser(req,resp,user1);
            System.out.println("后端获取用户:"+user1.toString());
            resp.sendRedirect("GetAllServlet");
        }else{
            System.out.println("登录失败");
            resp.sendRedirect("loginFail.html");
        }
    }

}
