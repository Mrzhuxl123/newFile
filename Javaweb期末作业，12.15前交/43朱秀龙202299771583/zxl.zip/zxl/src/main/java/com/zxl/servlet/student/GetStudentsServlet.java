package com.zxl.servlet.student;

import com.zxl.dao.StudentDao;
import com.zxl.dao.daoImp.StudentImp;
import com.zxl.domain.Student;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/GetStudentsServlet")
public class GetStudentsServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        String s = req.getParameter("s");
        System.out.println("模糊查询获取的值为" + s);
        StudentDao studentDao = new StudentImp();
        List<Student> students = studentDao.getStudents(s);
        System.out.println(students.toString());
        req.setAttribute("allStudent", students);
        if (students.size() == 0) {
            Student student = new Student();
            students.add(student);
        }
        req.getRequestDispatcher("studentList.jsp").forward(req, resp);
    }
}
